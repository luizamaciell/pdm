package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    String strN1 ="";
    String strN2 ="";
    TextView txtResult2;
    String op2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtResult2 = findViewById(R.id.txtResult2);
    }

    public void clickNumbers(View view) {
       Button btn = (Button) view;
       String number = btn.getText().toString();
        float n1 =  Float.parseFloat(etNumber1.getText().toString());
        float n2 =  Float.parseFloat(etNumber2.getText().toString());
       strN1 = strN1 + number;
       strN2 = strN2 + number;
       txtResult2.setText(strN1);

        if(operador.equals("+")){
            result = strN1 + n2;

        }

        else if(operador.equals  ("-")){
            result = strN1 - n2;
        }

        else if(operador.equals ("*")){
            result = n1 * n2;
        }

        else if(operador.equals ("/")){
            result = n1 / n2;
        }

        txtResult.setText("" + result );
    }

    }
    public void clickBtnOp2(View view) {
        Button btn = (Button) view;
        op2 = (btn.getText().toString());

    }
    public void clickBtnEquals2(View view) {

        }
}
    /*
    preenche strN1
    quando vai preencher N2, voces tambem ja sabem (clicar no op)
    String op = "";

    boolean preenchendo N1 = true;

    se op.equals("") for vazio{
     preenche n1
    }Senao{
    preenche N2
    }
     */

}